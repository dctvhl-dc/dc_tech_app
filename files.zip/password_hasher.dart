import 'dart:convert';
import 'package:crypto/crypto.dart';

/// Không lưu mật khẩu thô trong Sheet — chỉ lưu SHA-256.
/// (Production nên dùng bcrypt/argon2 + salt qua backend riêng.)
class PasswordHasher {
  static String hash(String plain) =>
      sha256.convert(utf8.encode(plain)).toString();
  static bool verify(String plain, String hashed) => hash(plain) == hashed;
}
