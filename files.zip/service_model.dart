/// Một dòng trong danh mục "Services" (thiết bị / dịch vụ cho thuê).
class RentalService {
  final String id;
  final String name;
  final int price; // VND

  const RentalService({required this.id, required this.name, required this.price});

  factory RentalService.fromMap(Map<String, String> m) => RentalService(
        id: m['id'] ?? '',
        name: m['name'] ?? '',
        price: int.tryParse((m['price'] ?? '').replaceAll(RegExp(r'[^0-9]'), '')) ?? 0,
      );

  Map<String, String> toMap() => {'id': id, 'name': name, 'price': '$price'};
}
