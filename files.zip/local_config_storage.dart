import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Lưu Sheet ID + Service Account JSON trên THIẾT BỊ.
///
/// Lý do không đọc từ tab "Settings": app cần credentials để *mở* Sheet,
/// nên không thể lấy credentials từ chính Sheet đó (gà - trứng).
/// Màn hình Super Admin sẽ ghi vào đây; tab "Settings" chỉ chứa
/// thông tin công ty (tên, hotline...).
class LocalConfigStorage {
  static const _storage = FlutterSecureStorage();
  static const _kSheetId = 'sheet_id';
  static const _kCredentials = 'api_credentials';

  static Future<({String? sheetId, String? credentials})> load() async => (
        sheetId: await _storage.read(key: _kSheetId),
        credentials: await _storage.read(key: _kCredentials),
      );

  static Future<void> save(
      {required String sheetId, required String credentials}) async {
    await _storage.write(key: _kSheetId, value: sheetId);
    await _storage.write(key: _kCredentials, value: credentials);
  }
}
