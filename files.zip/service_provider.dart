import 'package:flutter/foundation.dart';

import '../data/models/service_model.dart';
import '../data/services/google_sheets_service.dart';

/// Danh mục dịch vụ (tab "Services").
class ServiceProvider extends ChangeNotifier {
  final _sheets = GoogleSheetsService.instance;
  List<RentalService> services = [];
  bool loading = false;

  Future<void> load({bool force = false}) async {
    if (services.isNotEmpty && !force) return; // cache trong phiên
    loading = true;
    notifyListeners();
    try {
      services = await _sheets.fetchServices();
    } finally {
      loading = false;
      notifyListeners();
    }
  }
}
