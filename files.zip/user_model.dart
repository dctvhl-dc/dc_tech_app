/// Vai trò + quyền (RBAC). Mọi kiểm tra quyền đặt ở đây để UI chỉ hỏi `role.canXxx`.
enum UserRole {
  superAdmin('super_admin', 'Super Admin'),
  admin('admin', 'Admin'),
  user('user', 'User');

  final String value; // giá trị lưu trong Sheet
  final String label;
  const UserRole(this.value, this.label);

  static UserRole fromString(String? s) => UserRole.values
      .firstWhere((r) => r.value == s?.trim(), orElse: () => UserRole.user);

  bool get canConfigureApi => this == superAdmin;
  bool get canManageUsers => this != user;
  bool get canManageServices => this != user;
  bool get canViewReports => this != user;
  bool get canSeeAllBookings => this != user; // User chỉ thấy đơn của mình
}

class AppUser {
  final String id;
  final String username;
  final String passwordHash;
  final UserRole role;
  final String fullName;
  final String phone;
  final bool isActive;

  const AppUser({
    required this.id,
    required this.username,
    required this.passwordHash,
    required this.role,
    this.fullName = '',
    this.phone = '',
    this.isActive = true,
  });

  /// [m] là 1 hàng từ Sheet: key = tên cột, value = String.
  factory AppUser.fromMap(Map<String, String> m) => AppUser(
        id: m['id'] ?? '',
        username: m['username'] ?? '',
        passwordHash: m['password'] ?? '',
        role: UserRole.fromString(m['role']),
        fullName: m['full_name'] ?? '',
        phone: m['phone'] ?? '',
        // Ô trống => mặc định đang hoạt động
        isActive: (m['is_active'] ?? 'TRUE').toUpperCase() != 'FALSE',
      );

  Map<String, String> toMap() => {
        'id': id,
        'username': username,
        'password': passwordHash,
        'role': role.value,
        'full_name': fullName,
        'phone': phone,
        'is_active': isActive ? 'TRUE' : 'FALSE',
      };

  String get displayName => fullName.isNotEmpty ? fullName : username;
}
