import 'package:flutter/foundation.dart';

import '../data/models/user_model.dart';
import '../data/services/google_sheets_service.dart';

/// Danh sách nhân viên (Admin dùng để gán đơn / quản lý tài khoản).
class UserProvider extends ChangeNotifier {
  final _sheets = GoogleSheetsService.instance;
  List<AppUser> users = [];

  Future<void> load() async {
    users = await _sheets.fetchUsers();
    notifyListeners();
  }
}
