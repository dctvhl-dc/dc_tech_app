import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'core/utils/local_config_storage.dart';
import 'data/services/google_sheets_service.dart';
import 'providers/auth_provider.dart';
import 'providers/booking_provider.dart';
import 'providers/service_provider.dart';
import 'providers/user_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => AuthProvider()),
      ChangeNotifierProvider(create: (_) => BookingProvider()),
      ChangeNotifierProvider(create: (_) => ServiceProvider()),
      ChangeNotifierProvider(create: (_) => UserProvider()),
    ],
    child: MaterialApp(
      title: 'DC TECH',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const _Bootstrap(),
    ),
  ));
}

/// Khởi động: đọc credentials từ máy -> kết nối Sheets -> vào Login.
class _Bootstrap extends StatelessWidget {
  const _Bootstrap();

  Future<bool> _connect() async {
    final cfg = await LocalConfigStorage.load();
    if (cfg.sheetId == null || cfg.credentials == null) return false;
    await GoogleSheetsService.instance
        .init(credentialsJson: cfg.credentials!, spreadsheetId: cfg.sheetId!);
    return true;
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
        future: _connect(),
        builder: (_, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          // TODO: snap.data == true  -> LoginScreen -> MainShell (menu theo role)
          // TODO: snap.data == false -> ApiConfigScreen (chỉ Super Admin)
          return Scaffold(
              body: Center(child: Text(snap.data == true ? 'TODO: LoginScreen' : 'TODO: ApiConfigScreen')));
        },
      );
}
