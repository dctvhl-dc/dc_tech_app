import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/models/booking_model.dart';
import '../../../data/models/service_model.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/booking_provider.dart';
import '../../../providers/service_provider.dart';
import '../../../providers/user_provider.dart';

/// Màn hình Tạo / Sửa đơn hàng.
/// - Tạo mới: `AddBookingScreen()`
/// - Sửa:     `AddBookingScreen(booking: existing)`
/// Trả về `true` qua Navigator.pop khi lưu thành công (để màn danh sách refresh).
class AddBookingScreen extends StatefulWidget {
  final Booking? booking;
  const AddBookingScreen({super.key, this.booking});

  @override
  State<AddBookingScreen> createState() => _AddBookingScreenState();
}

/// Controller cho 1 dòng dịch vụ (tên + giá).
class _ServiceLine {
  final TextEditingController name;
  final TextEditingController price;
  _ServiceLine({String n = '', int p = 0})
      : name = TextEditingController(text: n),
        price = TextEditingController(text: p == 0 ? '' : Fmt.thousands(p));
  void dispose() {
    name.dispose();
    price.dispose();
  }
}

class _AddBookingScreenState extends State<AddBookingScreen> {
  final _formKey = GlobalKey<FormState>();

  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _gps = TextEditingController();
  final _invoiceInfo = TextEditingController();
  final _total = TextEditingController();
  final _paid = TextEditingController();
  final _submitted = TextEditingController();
  final List<_ServiceLine> _lines = [];

  DateTime? _serviceTime, _installTime, _collectTime;
  bool _requireInvoice = false;
  bool _totalManual = false; // true khi người dùng tự sửa tổng -> ngừng auto cộng
  bool _locating = false;
  bool _saving = false;
  BookingStatus _status = BookingStatus.pending;
  String? _assignedUser;

  bool get _isEdit => widget.booking != null;

  /// Công nợ = Tổng - Đã thanh toán (tính realtime, chỉ hiển thị, không nhập).
  int get _debt => Fmt.parseMoney(_total.text) - Fmt.parseMoney(_paid.text);

  @override
  void initState() {
    super.initState();
    final b = widget.booking;
    final auth = context.read<AuthProvider>();

    if (b != null) {
      _name.text = b.customerName;
      _phone.text = b.customerPhone;
      _address.text = b.locationText;
      _gps.text = b.gpsLocation;
      _invoiceInfo.text = b.invoiceInfo;
      _total.text = b.totalCost == 0 ? '' : Fmt.thousands(b.totalCost);
      _paid.text = b.paidAmount == 0 ? '' : Fmt.thousands(b.paidAmount);
      _submitted.text = b.submittedToCompany == 0 ? '' : Fmt.thousands(b.submittedToCompany);
      _serviceTime = b.serviceTime;
      _installTime = b.installTime;
      _collectTime = b.collectTime;
      _requireInvoice = b.requireInvoice;
      _status = b.status;
      _totalManual = true; // đơn cũ: giữ nguyên tổng đã lưu
      _lines.addAll(b.services.map((s) => _ServiceLine(n: s.name, p: s.price)));
    }
    if (_lines.isEmpty) _lines.add(_ServiceLine());

    // User thường: đơn luôn gán cho chính mình
    _assignedUser = b?.assignedUser ?? auth.currentUser?.username;

    // Công nợ cập nhật realtime khi gõ
    _total.addListener(_refresh);
    _paid.addListener(_refresh);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ServiceProvider>().load();
      if (auth.role.canSeeAllBookings) context.read<UserProvider>().load();
    });
  }

  @override
  void dispose() {
    for (final c in [_name, _phone, _address, _gps, _invoiceInfo, _total, _paid, _submitted]) {
      c.dispose();
    }
    for (final l in _lines) {
      l.dispose();
    }
    super.dispose();
  }

  void _refresh() => setState(() {});

  /// Tự cộng giá các dịch vụ vào "Tổng chi phí" (trừ khi user đã tự sửa tổng).
  void _recalcTotal() {
    if (_totalManual) return;
    final sum = _lines.fold<int>(0, (s, l) => s + Fmt.parseMoney(l.price.text));
    _total.text = sum == 0 ? '' : Fmt.thousands(sum);
  }

  // ───────────────────────── Actions ─────────────────────────

  void _snack(String msg, {bool error = true}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error ? AppColors.red : AppColors.green,
    ));
  }

  Future<DateTime?> _pickDateTime(DateTime? current) async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: current ?? now,
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 3),
    );
    if (d == null || !mounted) return null;
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(current ?? now),
    );
    if (t == null) return null;
    return DateTime(d.year, d.month, d.day, t.hour, t.minute);
  }

  /// Lấy tọa độ hiện tại -> lưu "lat,lng" vào field gps_location.
  /// Cần khai báo quyền: Android -> ACCESS_FINE_LOCATION trong AndroidManifest.xml.
  Future<void> _getGps() async {
    setState(() => _locating = true);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw StateError('Vui lòng bật dịch vụ định vị (GPS) trên thiết bị.');
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        throw StateError('Ứng dụng chưa được cấp quyền truy cập vị trí.');
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );
      _gps.text = '${pos.latitude.toStringAsFixed(6)},${pos.longitude.toStringAsFixed(6)}';
    } catch (e) {
      _snack(e is StateError ? e.message : 'Không lấy được vị trí: $e');
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final services = _lines
        .where((l) => l.name.text.trim().isNotEmpty)
        .map((l) => BookingServiceItem(name: l.name.text.trim(), price: Fmt.parseMoney(l.price.text)))
        .toList();
    if (services.isEmpty) return _snack('Vui lòng nhập ít nhất 1 dịch vụ');
    if (_installTime == null) return _snack('Vui lòng chọn thời gian giao');
    if (_collectTime == null) return _snack('Vui lòng chọn thời gian thu hồi');
    if (_collectTime!.isBefore(_installTime!)) {
      return _snack('Thời gian thu hồi phải sau thời gian giao');
    }

    final total = Fmt.parseMoney(_total.text);
    final paid = Fmt.parseMoney(_paid.text);
    final submitted = Fmt.parseMoney(_submitted.text);
    if (paid > total) return _snack('Số tiền đã thanh toán không được lớn hơn tổng chi phí');
    if (submitted > paid) return _snack('Số tiền đã nộp cty không được lớn hơn số đã thu');

    setState(() => _saving = true);
    try {
      final provider = context.read<BookingProvider>();
      final old = widget.booking;
      final booking = Booking(
        id: old?.id ?? await provider.nextId(),
        createdAt: old?.createdAt ?? DateTime.now(),
        customerName: _name.text.trim(),
        customerPhone: _phone.text.trim(),
        services: services,
        serviceTime: _serviceTime,
        installTime: _installTime,
        collectTime: _collectTime,
        locationText: _address.text.trim(),
        gpsLocation: _gps.text.trim(),
        totalCost: total,
        paidAmount: paid,
        submittedToCompany: submitted,
        requireInvoice: _requireInvoice,
        invoiceInfo: _requireInvoice ? _invoiceInfo.text.trim() : '',
        status: _status,
        assignedUser: _assignedUser ?? context.read<AuthProvider>().currentUser!.username,
      );
      await provider.save(booking, isNew: !_isEdit);
      if (!mounted) return;
      _snack('Đã lưu đơn ${booking.id}', error: false);
      Navigator.pop(context, true);
    } catch (e) {
      _snack('Lưu thất bại: $e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  // ───────────────────────── UI ─────────────────────────

  @override
  Widget build(BuildContext context) {
    final catalog = context.watch<ServiceProvider>().services;
    final canAssign = context.watch<AuthProvider>().role.canSeeAllBookings;

    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'SỬA ĐƠN HÀNG' : 'THÊM ĐƠN HÀNG MỚI')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            _section('THÔNG TIN KHÁCH HÀNG', [
              TextFormField(
                controller: _name,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'Họ và tên', prefixIcon: Icon(Icons.person_outline)),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Nhập tên khách hàng' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9+]'))],
                decoration: const InputDecoration(labelText: 'Số điện thoại', prefixIcon: Icon(Icons.phone_outlined)),
                validator: (v) => RegExp(r'^(0|\+84)\d{9,10}$').hasMatch(v?.trim() ?? '')
                    ? null
                    : 'Số điện thoại không hợp lệ',
              ),
            ]),

            _section('DỊCH VỤ', [
              for (var i = 0; i < _lines.length; i++) _serviceRow(i, catalog),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => setState(() => _lines.add(_ServiceLine())),
                  icon: const Icon(Icons.add),
                  label: const Text('Thêm dịch vụ'),
                ),
              ),
            ]),

            _section('THỜI GIAN & ĐỊA ĐIỂM', [
              _timeTile('Thời gian sử dụng (tuỳ chọn)', _serviceTime, (d) => _serviceTime = d),
              _timeTile('Thời gian giao', _installTime, (d) => _installTime = d),
              _timeTile('Thời gian thu hồi', _collectTime, (d) => _collectTime = d),
              const SizedBox(height: 12),
              TextFormField(
                controller: _address,
                maxLines: 2,
                decoration: const InputDecoration(labelText: 'Địa chỉ', prefixIcon: Icon(Icons.location_on_outlined)),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Nhập địa chỉ giao loa' : null,
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: TextFormField(
                    controller: _gps,
                    readOnly: true, // chỉ nhận giá trị từ nút định vị
                    decoration: const InputDecoration(labelText: 'Toạ độ GPS (lat,lng)'),
                  ),
                ),
                const SizedBox(width: 12),
                FilledButton.icon(
                  onPressed: _locating ? null : _getGps,
                  style: FilledButton.styleFrom(minimumSize: const Size(0, 54)),
                  icon: _locating
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.my_location),
                  label: const Text('Định vị', style: TextStyle(fontSize: 14)),
                ),
              ]),
            ]),

            _section('TÀI CHÍNH', [
              _moneyField(_total, 'Tổng chi phí', onUserEdit: () => _totalManual = true, required: true),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _moneyField(_paid, 'Đã thanh toán')),
                const SizedBox(width: 12),
                Expanded(child: _moneyField(_submitted, 'Đã nộp cty')),
              ]),
              const SizedBox(height: 12),
              _debtTile(),
            ]),

            _section('HOÁ ĐƠN', [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Yêu cầu xuất hoá đơn'),
                value: _requireInvoice,
                activeColor: AppColors.orange,
                onChanged: (v) => setState(() => _requireInvoice = v),
              ),
              if (_requireInvoice)
                TextFormField(
                  controller: _invoiceInfo,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Thông tin xuất hoá đơn (MST, tên cty, địa chỉ, email)'),
                  validator: (v) => (_requireInvoice && (v == null || v.trim().isEmpty))
                      ? 'Nhập thông tin xuất hoá đơn'
                      : null,
                ),
            ]),

            _section('QUẢN LÝ ĐƠN', [
              if (_isEdit)
                DropdownButtonFormField<BookingStatus>(
                  // ignore: deprecated_member_use
                  value: _status,
                  decoration: const InputDecoration(labelText: 'Trạng thái'),
                  items: [for (final s in BookingStatus.values) DropdownMenuItem(value: s, child: Text(s.label))],
                  onChanged: (v) => setState(() => _status = v ?? _status),
                ),
              if (_isEdit && canAssign) const SizedBox(height: 12),
              if (canAssign) _assigneeDropdown(),
            ]),

            const SizedBox(height: 8),
            FilledButton(
              onPressed: _saving ? null : _save,
              child: _saving
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                  : const Text('LƯU ĐƠN HÀNG'),
            ),
          ],
        ),
      ),
    );
  }

  // ───────────────────────── Widget con ─────────────────────────

  Widget _section(String title, List<Widget> children) => Padding(
        padding: const EdgeInsets.only(top: 18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 8),
            child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white.withOpacity(0.1)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
          ),
        ]),
      );

  /// 1 dòng dịch vụ: gõ tay tên + giá, hoặc bấm mũi tên để chọn từ danh mục.
  /// Sau khi chọn vẫn sửa được cả tên lẫn giá.
  Widget _serviceRow(int i, List<RentalService> catalog) {
    final line = _lines[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
          flex: 3,
          child: TextFormField(
            controller: line.name,
            decoration: InputDecoration(
              labelText: 'Thiết bị / dịch vụ',
              suffixIcon: PopupMenuButton<RentalService>(
                tooltip: 'Chọn từ danh mục',
                icon: const Icon(Icons.arrow_drop_down),
                enabled: catalog.isNotEmpty,
                onSelected: (s) {
                  line.name.text = s.name; // điền tên + load giá từ danh mục
                  line.price.text = Fmt.thousands(s.price);
                  _recalcTotal();
                  setState(() {});
                },
                itemBuilder: (_) => [
                  for (final s in catalog)
                    PopupMenuItem(value: s, child: Text('${s.name} — ${Fmt.money(s.price)}')),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          flex: 2,
          child: TextFormField(
            controller: line.price,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.right,
            inputFormatters: [ThousandsInputFormatter()],
            decoration: const InputDecoration(labelText: 'Giá thuê', suffixText: 'đ'),
            onChanged: (_) => _recalcTotal(),
          ),
        ),
        if (_lines.length > 1)
          IconButton(
            icon: const Icon(Icons.remove_circle_outline, color: AppColors.red),
            onPressed: () => setState(() {
              _lines.removeAt(i).dispose();
              _recalcTotal();
            }),
          ),
      ]),
    );
  }

  Widget _timeTile(String label, DateTime? value, void Function(DateTime) onPicked) => ListTile(
        contentPadding: EdgeInsets.zero,
        dense: true,
        leading: const Icon(Icons.event_available_outlined, color: AppColors.textMuted),
        title: Text(label),
        trailing: Text(Fmt.dateTime(value),
            style: TextStyle(fontWeight: FontWeight.w600, color: value == null ? AppColors.textMuted : Colors.white)),
        onTap: () async {
          final picked = await _pickDateTime(value);
          if (picked != null) setState(() => onPicked(picked));
        },
      );

  Widget _moneyField(TextEditingController c, String label,
          {VoidCallback? onUserEdit, bool required = false}) =>
      TextFormField(
        controller: c,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.right,
        inputFormatters: [ThousandsInputFormatter()],
        decoration: InputDecoration(labelText: label, suffixText: 'đ'),
        onChanged: (_) => onUserEdit?.call(),
        validator: required ? (v) => Fmt.parseMoney(v ?? '') <= 0 ? 'Nhập tổng chi phí' : null : null,
      );

  Widget _debtTile() {
    final debt = _debt;
    final color = debt > 0 ? AppColors.orange : AppColors.green;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Công nợ (tự tính)', style: TextStyle(color: color)),
        Text(Fmt.money(debt < 0 ? 0 : debt),
            style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w800)),
      ]),
    );
  }

  /// Admin/Super Admin chọn nhân viên phụ trách đơn.
  Widget _assigneeDropdown() {
    final users = context.watch<UserProvider>().users.where((u) => u.isActive).toList();
    // Tránh lỗi Dropdown khi value không có trong items (đang tải)
    final value = users.any((u) => u.username == _assignedUser) ? _assignedUser : null;
    return DropdownButtonFormField<String>(
      // ignore: deprecated_member_use
      value: value,
      decoration: const InputDecoration(labelText: 'Nhân viên phụ trách', prefixIcon: Icon(Icons.badge_outlined)),
      items: [for (final u in users) DropdownMenuItem(value: u.username, child: Text(u.displayName))],
      onChanged: (v) => setState(() => _assignedUser = v),
    );
  }
}
