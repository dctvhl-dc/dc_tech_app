import 'package:gsheets/gsheets.dart';

import '../../core/constants/app_constants.dart';
import '../../core/utils/password_hasher.dart';
import '../models/booking_model.dart';
import '../models/service_model.dart';
import '../models/user_model.dart';

class SheetsException implements Exception {
  final String message;
  SheetsException(this.message);
  @override
  String toString() => message;
}

/// Lớp duy nhất nói chuyện với Google Sheets (Singleton).
///
/// Các Provider chỉ gọi hàm typed ở dưới (fetchBookings, addBooking...),
/// không biết gì về gsheets -> sau này đổi sang backend/Firebase chỉ cần
/// thay file này.
///
/// Điều kiện: Sheet phải được *Share* cho email của Service Account (quyền Editor).
class GoogleSheetsService {
  GoogleSheetsService._();
  static final GoogleSheetsService instance = GoogleSheetsService._();

  Spreadsheet? _spreadsheet;
  final Map<String, Worksheet> _sheets = {};

  bool get isReady => _spreadsheet != null;

  // ───────────────────────── Kết nối ─────────────────────────

  /// [credentialsJson]: nội dung file JSON của Service Account.
  /// Tự tạo 4 tab + header nếu chưa có, và seed tài khoản super admin đầu tiên.
  Future<void> init({
    required String credentialsJson,
    required String spreadsheetId,
  }) async {
    try {
      final gsheets = GSheets(credentialsJson);
      _spreadsheet = await gsheets.spreadsheet(spreadsheetId);
      _sheets.clear();
      for (final e in SheetSchema.headers.entries) {
        _sheets[e.key] = await _ensureWorksheet(e.key, e.value);
      }
      await _seedDefaultSuperAdmin();
    } catch (e) {
      _spreadsheet = null;
      throw SheetsException('Không kết nối được Google Sheets: $e');
    }
  }

  Future<Worksheet> _ensureWorksheet(String title, List<String> headers) async {
    var ws = _spreadsheet!.worksheetByTitle(title);
    ws ??= await _spreadsheet!.addWorksheet(title);
    final firstRow = await ws.values.row(1);
    if (firstRow == null || firstRow.isEmpty) {
      await ws.values.insertRow(1, headers); // ghi header vào hàng 1
    }
    return ws;
  }

  /// Sheet mới tinh => chưa ai đăng nhập được. Tạo admin/admin123,
  /// BẮT BUỘC đổi mật khẩu ngay sau lần đăng nhập đầu tiên.
  Future<void> _seedDefaultSuperAdmin() async {
    if ((await fetchUsers()).isNotEmpty) return;
    await saveUser(AppUser(
      id: 'U-1',
      username: 'admin',
      passwordHash: PasswordHasher.hash('admin123'),
      role: UserRole.superAdmin,
      fullName: 'Super Admin',
    ));
  }

  Worksheet _ws(String name) {
    final ws = _sheets[name];
    if (ws == null) throw SheetsException('Chưa kết nối Google Sheets.');
    return ws;
  }

  // ───────────────── CRUD generic (theo cột "id" = cột A) ─────────────────

  /// Đọc toàn bộ hàng (bỏ header). Mỗi hàng là Map<tên_cột, giá_trị>.
  Future<List<Map<String, String>>> _getAll(String sheet) async =>
      await _ws(sheet).values.map.allRows() ?? [];

  Future<void> _append(String sheet, Map<String, String> row) async {
    final ok = await _ws(sheet).values.map.appendRow(row);
    if (!ok) throw SheetsException('Ghi dữ liệu vào "$sheet" thất bại.');
  }

  Future<void> _updateById(String sheet, String id, Map<String, String> row) async {
    final ok = await _ws(sheet).values.map.updateRowByKey(id, row);
    if (!ok) throw SheetsException('Không tìm thấy id "$id" trong "$sheet".');
  }

  Future<void> _deleteById(String sheet, String id) async {
    final ws = _ws(sheet);
    final ids = await ws.values.column(1); // gồm cả header ở vị trí 0
    final index = ids.indexOf(id);
    if (index < 1) throw SheetsException('Không tìm thấy id "$id" trong "$sheet".');
    await ws.deleteRow(index + 1); // chỉ số hàng trong Sheets bắt đầu từ 1
  }

  /// Sinh mã tăng dần: TL-1001, TL-1002...
  /// Lưu ý: 2 máy tạo đơn cùng lúc có thể trùng mã (Sheets không có
  /// transaction). Quy mô nhỏ thì chấp nhận được.
  Future<String> _nextId(String sheet, String prefix, int start) async {
    final ids = await _ws(sheet).values.column(1);
    var max = start - 1;
    for (final id in ids.skip(1)) {
      final n = int.tryParse(id.replaceAll(RegExp(r'[^0-9]'), ''));
      if (n != null && n > max) max = n;
    }
    return '$prefix-${max + 1}';
  }

  // ───────────────────────── Users ─────────────────────────

  Future<List<AppUser>> fetchUsers() async =>
      (await _getAll(SheetNames.users)).map(AppUser.fromMap).toList();

  Future<void> saveUser(AppUser u) => _append(SheetNames.users, u.toMap());
  Future<void> updateUser(AppUser u) => _updateById(SheetNames.users, u.id, u.toMap());
  Future<String> nextUserId() => _nextId(SheetNames.users, 'U', 1);

  // ───────────────────────── Services ─────────────────────────

  Future<List<RentalService>> fetchServices() async =>
      (await _getAll(SheetNames.services)).map(RentalService.fromMap).toList();

  Future<void> addService(RentalService s) => _append(SheetNames.services, s.toMap());
  Future<void> updateService(RentalService s) => _updateById(SheetNames.services, s.id, s.toMap());
  Future<void> deleteService(String id) => _deleteById(SheetNames.services, id);
  Future<String> nextServiceId() => _nextId(SheetNames.services, 'S', 1);

  // ───────────────────────── Bookings ─────────────────────────

  /// Truyền [assignedUser] để chỉ lấy đơn của 1 nhân viên (role User).
  /// Lưu ý: lọc ở phía client — Sheets API không có query.
  Future<List<Booking>> fetchBookings({String? assignedUser}) async {
    final all = (await _getAll(SheetNames.bookings)).map(Booking.fromMap);
    final list = assignedUser == null
        ? all.toList()
        : all.where((b) => b.assignedUser == assignedUser).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt)); // mới nhất trước
    return list;
  }

  Future<void> addBooking(Booking b) => _append(SheetNames.bookings, b.toMap());
  Future<void> updateBooking(Booking b) => _updateById(SheetNames.bookings, b.id, b.toMap());
  Future<void> deleteBooking(String id) => _deleteById(SheetNames.bookings, id);
  Future<String> nextBookingId() => _nextId(SheetNames.bookings, 'TL', 1001);

  // ───────────────────────── Settings (key/value) ─────────────────────────

  Future<Map<String, String>> fetchSettings() async {
    final rows = await _getAll(SheetNames.settings);
    return {for (final r in rows) r['key'] ?? '': r['value'] ?? ''};
  }

  Future<void> saveSetting(String key, String value) async {
    final ws = _ws(SheetNames.settings);
    final exists = (await ws.values.column(1)).contains(key);
    final row = {'key': key, 'value': value};
    exists ? await ws.values.map.updateRowByKey(key, row) : await ws.values.map.appendRow(row);
  }
}
