import 'package:flutter/foundation.dart';

import '../core/utils/password_hasher.dart';
import '../data/models/user_model.dart';
import '../data/services/google_sheets_service.dart';

class AuthProvider extends ChangeNotifier {
  final _sheets = GoogleSheetsService.instance;

  AppUser? currentUser;
  bool loading = false;
  String? error;

  bool get isLoggedIn => currentUser != null;
  UserRole get role => currentUser?.role ?? UserRole.user;

  Future<bool> login(String username, String password) async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final users = await _sheets.fetchUsers();
      final match = users.where((u) =>
          u.username.toLowerCase() == username.trim().toLowerCase() &&
          PasswordHasher.verify(password, u.passwordHash));
      if (match.isEmpty) {
        error = 'Sai tên đăng nhập hoặc mật khẩu';
      } else if (!match.first.isActive) {
        error = 'Tài khoản đã bị khóa';
      } else {
        currentUser = match.first;
      }
    } catch (e) {
      error = e.toString();
    }
    loading = false;
    notifyListeners();
    return currentUser != null;
  }

  void logout() {
    currentUser = null;
    notifyListeners();
  }
}
