/// Tên các tab trong Google Sheet.
class SheetNames {
  static const users = 'Users';
  static const services = 'Services';
  static const bookings = 'Bookings';
  static const settings = 'Settings';
}

/// Header (hàng 1) của từng tab. gsheets dùng hàng này làm "key" cho Map.
/// => KHÔNG đổi tên cột sau khi đã có dữ liệu.
class SheetSchema {
  static const Map<String, List<String>> headers = {
    SheetNames.users: [
      'id', 'username', 'password', 'role', 'full_name', 'phone', 'is_active',
    ],
    SheetNames.services: ['id', 'name', 'price'],
    SheetNames.bookings: [
      'id', 'created_at', 'customer_name', 'customer_phone', 'services_info',
      'service_time', 'install_time', 'collect_time', 'location_text',
      'gps_location', 'total_cost', 'paid_amount', 'submitted_to_company',
      'debt_amount', 'require_invoice', 'invoice_info', 'status',
      'assigned_user',
    ],
    // Dạng key/value: company_name, hotline, ...
    SheetNames.settings: ['key', 'value'],
  };
}
