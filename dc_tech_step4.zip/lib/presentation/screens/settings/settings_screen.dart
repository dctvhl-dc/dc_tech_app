import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/user_provider.dart';
import '../../widgets/change_password_dialog.dart';
import '../service/service_catalog_screen.dart';
import '../users/user_management_screen.dart';
import 'api_config_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.currentUser!;
    // Số nhân viên đang chờ được reset mật khẩu (hiện badge cho Admin)
    final pending = context.watch<UserProvider>().users.where((u) => u.resetRequested.isNotEmpty).length;

    Widget tile(IconData icon, String title, VoidCallback onTap, {Color? color, String? subtitle}) => Card(
          color: AppColors.surface,
          margin: const EdgeInsets.only(bottom: 10),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: ListTile(
            leading: Icon(icon, color: color ?? AppColors.orange),
            title: Text(title, style: TextStyle(color: color)),
            subtitle: subtitle == null ? null : Text(subtitle, style: const TextStyle(color: AppColors.orange)),
            trailing: const Icon(Icons.chevron_right),
            onTap: onTap,
          ),
        );

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('CÀI ĐẶT', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          Card(
            color: AppColors.surface,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: AppColors.orange,
                child: Text(user.displayName[0].toUpperCase()),
              ),
              title: Text(user.displayName, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('@${user.username}'),
              trailing: Chip(label: Text(user.role.label), side: BorderSide.none),
            ),
          ),
          const SizedBox(height: 14),
          if (user.role.canConfigureApi)
            tile(Icons.cloud_sync_outlined, 'Kết nối Google Sheets', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ApiConfigScreen()));
            }),
          if (user.role.canManageServices)
            tile(Icons.speaker_group_outlined, 'Danh mục dịch vụ', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ServiceCatalogScreen()));
            }),
          if (user.role.canManageUsers)
            tile(
              Icons.group_outlined,
              'Quản lý nhân viên',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UserManagementScreen())),
              subtitle: pending > 0 ? '$pending yêu cầu reset mật khẩu' : null,
            ),
          tile(Icons.password_outlined, 'Đổi mật khẩu', () async {
            final ok = await showDialog<bool>(context: context, builder: (_) => const ChangePasswordDialog());
            if (ok == true && context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Đã đổi mật khẩu'), backgroundColor: AppColors.green));
            }
          }),
          tile(Icons.logout, 'Đăng xuất', () => context.read<AuthProvider>().logout(), color: AppColors.red),
        ],
      ),
    );
  }
}
