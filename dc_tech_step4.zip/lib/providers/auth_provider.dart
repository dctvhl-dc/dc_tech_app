import 'package:flutter/foundation.dart';

import '../core/utils/password_hasher.dart';
import '../data/models/user_model.dart';
import '../data/services/google_sheets_service.dart';

class AuthProvider extends ChangeNotifier {
  final _sheets = GoogleSheetsService.instance;

  AppUser? currentUser;
  bool loading = false;
  String? error;

  bool get isLoggedIn => currentUser != null;
  UserRole get role => currentUser?.role ?? UserRole.user;

  Future<bool> login(String username, String password) async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final users = await _sheets.fetchUsers();
      final byName = users.where(
          (u) => u.username.trim().toLowerCase() == username.trim().toLowerCase());
      // Log chẩn đoán (chỉ in ở chế độ debug, không in mật khẩu)
      debugPrint('[login] số user=${users.length}, '
          'tìm thấy username=${byName.isNotEmpty}, '
          'cột password dạng hash=${byName.isNotEmpty && PasswordHasher.isHashed(byName.first.passwordHash)}');

      final match = byName.where((u) => PasswordHasher.verify(password, u.passwordHash));
      if (match.isEmpty) {
        error = 'Sai tên đăng nhập hoặc mật khẩu';
      } else if (!match.first.isActive) {
        error = 'Tài khoản đã bị khóa';
      } else {
        var user = match.first;
        // Mật khẩu đang lưu dạng thô (vd: tự gõ vào Sheet để khôi phục) -> ghi lại dạng hash
        if (!PasswordHasher.isHashed(user.passwordHash)) {
          try {
            final upgraded = user.copyWith(passwordHash: PasswordHasher.hash(password));
            await _sheets.updateUser(upgraded);
            user = upgraded;
          } catch (_) {}
        }
        currentUser = user;
      }
    } catch (e) {
      error = e.toString();
    }
    loading = false;
    notifyListeners();
    return currentUser != null;
  }

  /// Trả về null nếu thành công, ngược lại là thông báo lỗi.
  Future<String?> changePassword(String oldPw, String newPw) async {
    final u = currentUser;
    if (u == null) return 'Chưa đăng nhập';
    if (!PasswordHasher.verify(oldPw, u.passwordHash)) return 'Mật khẩu hiện tại không đúng';
    if (newPw.length < 6) return 'Mật khẩu mới tối thiểu 6 ký tự';
    if (newPw == oldPw) return 'Mật khẩu mới phải khác mật khẩu hiện tại';
    try {
      final updated = u.copyWith(
        passwordHash: PasswordHasher.hash(newPw),
        mustChangePassword: false, // đã đổi xong -> bỏ yêu cầu bắt buộc
        resetRequested: '',
      );
      await _sheets.updateUser(updated);
      currentUser = updated;
      notifyListeners();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  static String _normPhone(String s) {
    var d = s.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('84')) d = '0${d.substring(2)}';
    return d;
  }

  /// "Quên mật khẩu": ghi yêu cầu để quản trị viên cấp mật khẩu tạm.
  /// Chỉ ghi khi username + số điện thoại khớp tài khoản đang hoạt động.
  /// LUÔN trả về thành công khi không lỗi mạng, để người ngoài không dò được
  /// tài khoản nào tồn tại.
  Future<String?> requestPasswordReset(String username, String phone) async {
    try {
      final users = await _sheets.fetchUsers();
      final match = users.where((u) =>
          u.username.trim().toLowerCase() == username.trim().toLowerCase() &&
          u.isActive &&
          u.phone.isNotEmpty &&
          _normPhone(u.phone) == _normPhone(phone));
      if (match.isNotEmpty) {
        await _sheets.updateUser(match.first.copyWith(resetRequested: DateTime.now().toIso8601String()));
      }
      return null;
    } catch (e) {
      return 'Không gửi được yêu cầu: $e';
    }
  }

  void logout() {
    currentUser = null;
    notifyListeners();
  }
}
