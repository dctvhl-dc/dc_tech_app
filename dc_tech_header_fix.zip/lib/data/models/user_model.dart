/// Vai trò + quyền (RBAC). Mọi kiểm tra quyền đặt ở đây để UI chỉ hỏi `role.canXxx`.
enum UserRole {
  superAdmin('super_admin', 'Super Admin'),
  admin('admin', 'Admin'),
  user('user', 'User');

  final String value; // giá trị lưu trong Sheet
  final String label;
  const UserRole(this.value, this.label);

  /// "Super Admin", "super_admin", "super-admin" đều nhận được.
  static UserRole fromString(String? s) {
    final n = (s ?? '').trim().toLowerCase().replaceAll(RegExp(r'[\s-]+'), '_');
    return UserRole.values.firstWhere((r) => r.value == n, orElse: () => UserRole.user);
  }

  bool get canConfigureApi => this == superAdmin;
  bool get canManageUsers => this != user;
  bool get canManageServices => this != user;
  bool get canViewReports => this != user;
  bool get canSeeAllBookings => this != user; // User chỉ thấy đơn của mình
}

class AppUser {
  final String id;
  final String username;
  final String passwordHash;
  final UserRole role;
  final String fullName;
  final String phone;
  final bool isActive;

  const AppUser({
    required this.id,
    required this.username,
    required this.passwordHash,
    required this.role,
    this.fullName = '',
    this.phone = '',
    this.isActive = true,
  });

  /// [m] là 1 hàng từ Sheet: key = tên cột, value = String.
  factory AppUser.fromMap(Map<String, String> m) => AppUser(
        id: m['id'] ?? '',
        username: m['username'] ?? '',
        passwordHash: m['password'] ?? '',
        role: UserRole.fromString(m['role']),
        fullName: m['full_name'] ?? '',
        phone: m['phone'] ?? '',
        isActive: _parseActive(m['is_active']),
      );

  Map<String, String> toMap() => {
        'id': id,
        'username': username,
        'password': passwordHash,
        'role': role.value,
        'full_name': fullName,
        'phone': phone,
        'is_active': isActive ? 'Hoạt động' : 'Khóa',
      };

  /// Ô trống => đang hoạt động. Chỉ các giá trị "khóa" mới coi là tắt.
  static bool _parseActive(String? s) {
    const off = {'false', '0', 'khóa', 'khoá', 'bị khóa', 'ngưng', 'inactive', 'locked', 'không hoạt động'};
    return !off.contains((s ?? '').trim().toLowerCase());
  }

  String get displayName => fullName.isNotEmpty ? fullName : username;
}
