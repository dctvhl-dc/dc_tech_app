import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Lưu Sheet ID + Service Account JSON trên THIẾT BỊ.
///
/// Lý do không đọc từ tab "Settings": app cần credentials để *mở* Sheet,
/// nên không thể lấy credentials từ chính Sheet đó (gà - trứng).
/// Màn hình Super Admin sẽ ghi vào đây; tab "Settings" chỉ chứa
/// thông tin công ty (tên, hotline...).
class LocalConfigStorage {
  static const _storage = FlutterSecureStorage();
  static const _kSheetId = 'sheet_id';
  static const _kCredentials = 'api_credentials';

  static Future<({String? sheetId, String? credentials})> load() async => (
        sheetId: await _storage.read(key: _kSheetId),
        credentials: await _storage.read(key: _kCredentials),
      );

  static Future<void> save(
      {required String sheetId, required String credentials}) async {
    await _storage.write(key: _kSheetId, value: sheetId);
    await _storage.write(key: _kCredentials, value: credentials);
  }

  // Nhắc lịch giao / thu (lưu trên từng máy)
  static Future<({bool enabled, int leadMinutes})> loadReminder() async {
    final e = await _storage.read(key: 'reminder_enabled');
    final l = await _storage.read(key: 'reminder_lead');
    return (enabled: e != 'false', leadMinutes: int.tryParse(l ?? '') ?? 60);
  }

  static Future<void> saveReminder({required bool enabled, required int leadMinutes}) async {
    await _storage.write(key: 'reminder_enabled', value: '$enabled');
    await _storage.write(key: 'reminder_lead', value: '$leadMinutes');
  }

  // ───────── Phiên đăng nhập (tự đăng nhập lại) ─────────
  static const _kSessUser = 'session_user_id';
  static const _kSessPwd = 'session_pwd_hash';
  static const _kSessAt = 'session_last_active';

  /// Lưu phiên sau khi đăng nhập. Lưu kèm mã băm mật khẩu để phát hiện mật khẩu
  /// đã bị đổi / reset ở nơi khác (khi đó phiên cũ không còn hiệu lực).
  static Future<void> saveSession({required String userId, required String passwordHash}) async {
    await _storage.write(key: _kSessUser, value: userId);
    await _storage.write(key: _kSessPwd, value: passwordHash);
    await _storage.write(key: _kSessAt, value: DateTime.now().toIso8601String());
  }

  static Future<({String userId, String passwordHash, DateTime lastActive})?> loadSession() async {
    final id = await _storage.read(key: _kSessUser);
    final pwd = await _storage.read(key: _kSessPwd);
    final at = DateTime.tryParse(await _storage.read(key: _kSessAt) ?? '');
    if (id == null || pwd == null || at == null) return null;
    return (userId: id, passwordHash: pwd, lastActive: at);
  }

  /// Gia hạn phiên: ghi lại thời điểm sử dụng gần nhất (chỉ khi đang có phiên).
  static Future<void> touchSession() async {
    if (await _storage.read(key: _kSessUser) == null) return;
    await _storage.write(key: _kSessAt, value: DateTime.now().toIso8601String());
  }

  static Future<void> clearSession() async {
    await _storage.delete(key: _kSessUser);
    await _storage.delete(key: _kSessPwd);
    await _storage.delete(key: _kSessAt);
  }

  // ───────── Ghi nhớ tên đăng nhập + mật khẩu (điền sẵn ở màn hình đăng nhập) ─────────
  // Lưu trong kho an toàn của hệ điều hành (Android Keystore / Windows).
  static Future<void> saveCredentials(String username, String password) async {
    await _storage.write(key: 'saved_username', value: username);
    await _storage.write(key: 'saved_password', value: password);
  }

  static Future<({String username, String password})?> loadCredentials() async {
    final u = await _storage.read(key: 'saved_username');
    final p = await _storage.read(key: 'saved_password');
    if (u == null || p == null) return null;
    return (username: u, password: p);
  }

  static Future<void> clearCredentials() async {
    await _storage.delete(key: 'saved_username');
    await _storage.delete(key: 'saved_password');
  }
}
