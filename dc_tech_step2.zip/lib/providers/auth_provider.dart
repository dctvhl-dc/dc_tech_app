import 'package:flutter/foundation.dart';

import '../core/utils/password_hasher.dart';
import '../data/models/user_model.dart';
import '../data/services/google_sheets_service.dart';

class AuthProvider extends ChangeNotifier {
  final _sheets = GoogleSheetsService.instance;

  AppUser? currentUser;
  bool loading = false;
  String? error;

  bool get isLoggedIn => currentUser != null;
  UserRole get role => currentUser?.role ?? UserRole.user;

  Future<bool> login(String username, String password) async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final users = await _sheets.fetchUsers();
      final match = users.where((u) =>
          u.username.toLowerCase() == username.trim().toLowerCase() &&
          PasswordHasher.verify(password, u.passwordHash));
      if (match.isEmpty) {
        error = 'Sai tên đăng nhập hoặc mật khẩu';
      } else if (!match.first.isActive) {
        error = 'Tài khoản đã bị khóa';
      } else {
        currentUser = match.first;
      }
    } catch (e) {
      error = e.toString();
    }
    loading = false;
    notifyListeners();
    return currentUser != null;
  }

  /// Trả về null nếu thành công, ngược lại là thông báo lỗi.
  Future<String?> changePassword(String oldPw, String newPw) async {
    final u = currentUser;
    if (u == null) return 'Chưa đăng nhập';
    if (!PasswordHasher.verify(oldPw, u.passwordHash)) return 'Mật khẩu hiện tại không đúng';
    if (newPw.length < 6) return 'Mật khẩu mới tối thiểu 6 ký tự';
    try {
      final updated = AppUser(
        id: u.id,
        username: u.username,
        passwordHash: PasswordHasher.hash(newPw),
        role: u.role,
        fullName: u.fullName,
        phone: u.phone,
        isActive: u.isActive,
      );
      await _sheets.updateUser(updated);
      currentUser = updated;
      notifyListeners();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  void logout() {
    currentUser = null;
    notifyListeners();
  }
}
