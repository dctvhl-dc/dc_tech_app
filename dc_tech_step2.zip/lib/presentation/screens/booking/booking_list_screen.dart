import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/models/booking_model.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/booking_provider.dart';
import 'add_booking_screen.dart';

/// Danh sách đơn: tìm kiếm, lọc trạng thái, bấm để sửa, nút nhanh Giao/Thu loa.
class BookingListScreen extends StatefulWidget {
  const BookingListScreen({super.key});
  @override
  State<BookingListScreen> createState() => _BookingListScreenState();
}

class _BookingListScreenState extends State<BookingListScreen> {
  final _search = TextEditingController();
  BookingStatus? _filter; // null = tất cả

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _reload());
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg), backgroundColor: AppColors.red));
  }

  Future<void> _reload() async {
    final user = context.read<AuthProvider>().currentUser;
    if (user == null) return;
    try {
      await context.read<BookingProvider>().load(user);
    } catch (e) {
      _snack('Không tải được danh sách đơn: $e');
    }
  }

  Future<void> _changeStatus(Booking b, BookingStatus s) async {
    try {
      await context.read<BookingProvider>().changeStatus(b, s);
    } catch (e) {
      _snack('Cập nhật thất bại: $e');
    }
  }

  Color _statusColor(BookingStatus s) => switch (s) {
        BookingStatus.pending => AppColors.orange,
        BookingStatus.delivered => AppColors.blue,
        BookingStatus.returned => AppColors.green,
      };

  @override
  Widget build(BuildContext context) {
    final p = context.watch<BookingProvider>();
    final q = _search.text.trim().toLowerCase();
    final list = p.bookings.where((b) {
      if (_filter != null && b.status != _filter) return false;
      if (q.isEmpty) return true;
      return b.customerName.toLowerCase().contains(q) ||
          b.customerPhone.contains(q) ||
          b.id.toLowerCase().contains(q);
    }).toList();

    return SafeArea(
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('DANH SÁCH ĐƠN HÀNG',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                hintText: 'Tìm khách hàng, SĐT, mã đơn...',
                prefixIcon: Icon(Icons.search),
              ),
            ),
            const SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _chip('Tất cả', null),
                for (final s in BookingStatus.values) _chip(s.label, s),
              ]),
            ),
          ]),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _reload,
            child: p.loading && p.bookings.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : list.isEmpty
                    ? ListView(children: const [
                        SizedBox(height: 120),
                        Center(child: Text('Chưa có đơn hàng nào', style: TextStyle(color: AppColors.textMuted))),
                      ])
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 90),
                        itemCount: list.length,
                        itemBuilder: (_, i) => _card(list[i]),
                      ),
          ),
        ),
      ]),
    );
  }

  Widget _chip(String label, BookingStatus? value) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: _filter == value,
          selectedColor: AppColors.orange,
          onSelected: (_) => setState(() => _filter = value),
        ),
      );

  Widget _card(Booking b) {
    final color = _statusColor(b.status);
    final services = b.services.map((s) => s.name).join(', ');
    return Card(
      color: AppColors.surface,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.push<bool>(
            context, MaterialPageRoute(builder: (_) => AddBookingScreen(booking: b))),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text('Mã: #${b.id}',
                    style: const TextStyle(color: AppColors.blue, fontSize: 17, fontWeight: FontWeight.w800)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(color: color.withValues(alpha: 0.25), borderRadius: BorderRadius.circular(20)),
                child: Text(b.status.label, style: TextStyle(color: color, fontWeight: FontWeight.w700)),
              ),
            ]),
            const Divider(height: 18),
            _row(Icons.person_outline, 'Khách: ${b.customerName} - ${b.customerPhone}'),
            _row(Icons.speaker_outlined, 'Dịch vụ: $services'),
            _row(Icons.event_outlined, 'Hạn thu: ${Fmt.dateTime(b.collectTime)}'),
            Row(children: [
              const Icon(Icons.account_balance_wallet_outlined, size: 20, color: AppColors.textMuted),
              const SizedBox(width: 8),
              Expanded(
                child: Text.rich(TextSpan(children: [
                  TextSpan(text: 'Công nợ: ${Fmt.money(b.debtAmount < 0 ? 0 : b.debtAmount)} / '),
                  TextSpan(
                    text: b.pendingToCompany > 0
                        ? 'Chưa nộp cty ${Fmt.money(b.pendingToCompany)}'
                        : 'Đã nộp cty',
                    style: TextStyle(color: b.pendingToCompany > 0 ? AppColors.orange : AppColors.green),
                  ),
                ])),
              ),
            ]),
            if (b.status != BookingStatus.returned) ...[
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerRight,
                child: FilledButton.tonal(
                  onPressed: () => _changeStatus(
                    b,
                    b.status == BookingStatus.pending ? BookingStatus.delivered : BookingStatus.returned,
                  ),
                  child: Text(b.status == BookingStatus.pending ? 'Giao loa' : 'Thu loa'),
                ),
              ),
            ],
          ]),
        ),
      ),
    );
  }

  Widget _row(IconData icon, String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(children: [
          Icon(icon, size: 20, color: AppColors.textMuted),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ]),
      );
}
