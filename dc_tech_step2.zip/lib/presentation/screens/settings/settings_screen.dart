import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../providers/auth_provider.dart';
import 'api_config_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.currentUser!;

    Widget tile(IconData icon, String title, VoidCallback onTap, {Color? color}) => Card(
          color: AppColors.surface,
          margin: const EdgeInsets.only(bottom: 10),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: ListTile(
            leading: Icon(icon, color: color ?? AppColors.orange),
            title: Text(title, style: TextStyle(color: color)),
            trailing: const Icon(Icons.chevron_right),
            onTap: onTap,
          ),
        );

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('CÀI ĐẶT', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          Card(
            color: AppColors.surface,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: AppColors.orange,
                child: Text(user.displayName[0].toUpperCase()),
              ),
              title: Text(user.displayName, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('@${user.username}'),
              trailing: Chip(label: Text(user.role.label), side: BorderSide.none),
            ),
          ),
          const SizedBox(height: 14),
          if (user.role.canConfigureApi)
            tile(Icons.cloud_sync_outlined, 'Kết nối Google Sheets', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ApiConfigScreen()));
            }),
          tile(Icons.password_outlined, 'Đổi mật khẩu', () async {
            final ok = await showDialog<bool>(context: context, builder: (_) => const _ChangePasswordDialog());
            if (ok == true && context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Đã đổi mật khẩu'), backgroundColor: AppColors.green));
            }
          }),
          tile(Icons.logout, 'Đăng xuất', () => context.read<AuthProvider>().logout(), color: AppColors.red),
        ],
      ),
    );
  }
}

class _ChangePasswordDialog extends StatefulWidget {
  const _ChangePasswordDialog();
  @override
  State<_ChangePasswordDialog> createState() => _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _old = TextEditingController();
  final _new = TextEditingController();
  final _confirm = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _old.dispose();
    _new.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_new.text != _confirm.text) {
      setState(() => _error = 'Mật khẩu xác nhận không khớp');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final err = await context.read<AuthProvider>().changePassword(_old.text, _new.text);
    if (!mounted) return;
    if (err == null) {
      Navigator.pop(context, true);
    } else {
      setState(() {
        _error = err;
        _busy = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget field(TextEditingController c, String label) => Padding(
          padding: const EdgeInsets.only(top: 12),
          child: TextField(controller: c, obscureText: true, decoration: InputDecoration(labelText: label)),
        );
    return AlertDialog(
      backgroundColor: AppColors.surface,
      title: const Text('Đổi mật khẩu'),
      content: SizedBox(
        width: 360,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          field(_old, 'Mật khẩu hiện tại'),
          field(_new, 'Mật khẩu mới (tối thiểu 6 ký tự)'),
          field(_confirm, 'Nhập lại mật khẩu mới'),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(_error!, style: const TextStyle(color: AppColors.red)),
            ),
        ]),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Hủy')),
        FilledButton(
          onPressed: _busy ? null : _save,
          style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
          child: const Text('Lưu'),
        ),
      ],
    );
  }
}
