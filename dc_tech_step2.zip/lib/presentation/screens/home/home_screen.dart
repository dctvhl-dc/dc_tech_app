import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/models/booking_model.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/booking_provider.dart';

/// Trang chủ tạm thời: số liệu tổng hợp từ các đơn đã tải.
/// (Màn Báo cáo đầy đủ theo tháng/quý/năm sẽ làm sau.)
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser!;
    final list = context.watch<BookingProvider>().bookings;
    final revenue = list.fold<int>(0, (s, b) => s + b.totalCost);
    final debt = list.fold<int>(0, (s, b) => s + b.debtAmount);
    final paid = list.fold<int>(0, (s, b) => s + b.paidAmount);
    final open = list.where((b) => b.status != BookingStatus.returned).length;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            const Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('DC TECH', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                Text('Quản lý thuê loa', style: TextStyle(color: AppColors.textMuted)),
              ]),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(user.displayName, style: const TextStyle(fontWeight: FontWeight.w700)),
              Chip(
                label: Text(user.role.label, style: const TextStyle(fontSize: 11, color: Colors.white)),
                backgroundColor: AppColors.orange,
                visualDensity: VisualDensity.compact,
                side: BorderSide.none,
              ),
            ]),
          ]),
          const SizedBox(height: 20),
          const Text('TỔNG QUAN', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Row(children: [
            _Stat('Doanh thu', revenue, AppColors.blue, Icons.trending_up),
            const SizedBox(width: 10),
            _Stat('Công nợ', debt, AppColors.red, Icons.warning_amber_rounded),
            const SizedBox(width: 10),
            _Stat('Đã thu', paid, AppColors.green, Icons.payments_outlined),
          ]),
          const SizedBox(height: 16),
          ListTile(
            tileColor: AppColors.surface,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            leading: const Icon(Icons.local_shipping_outlined, color: AppColors.orange),
            title: const Text('Đơn chưa hoàn tất'),
            trailing: Text('$open', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label;
  final int value;
  final Color color;
  final IconData icon;
  const _Stat(this.label, this.value, this.color, this.icon);

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.18),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color, width: 1.2),
          ),
          child: Column(children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 2),
            FittedBox(
              child: Text(Fmt.money(value), style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
          ]),
        ),
      );
}
