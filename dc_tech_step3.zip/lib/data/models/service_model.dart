/// Một dòng trong danh mục "Services" (thiết bị / dịch vụ cho thuê).
class RentalService {
  final String id;
  final String name;
  final int price; // VND
  final String description;
  final bool isActive; // false = ngưng cho thuê, không hiện khi tạo đơn

  const RentalService({
    required this.id,
    required this.name,
    required this.price,
    this.description = '',
    this.isActive = true,
  });

  static bool _parseActive(String? s) {
    const off = {'ngưng', 'ngưng hoạt động', 'tạm ngưng', 'khóa', 'khoá', 'false', '0', 'inactive'};
    return !off.contains((s ?? '').trim().toLowerCase());
  }

  factory RentalService.fromMap(Map<String, String> m) => RentalService(
        id: m['id'] ?? '',
        name: m['name'] ?? '',
        price: int.tryParse((m['price'] ?? '').replaceAll(RegExp(r'[^0-9]'), '')) ?? 0,
        description: m['description'] ?? '',
        isActive: _parseActive(m['status']),
      );

  Map<String, String> toMap() => {
        'id': id,
        'name': name,
        'price': '$price',
        'description': description,
        'status': isActive ? 'Hoạt động' : 'Ngưng hoạt động',
      };
}
