import 'dart:io';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

import '../../data/models/booking_model.dart';
import '../utils/local_config_storage.dart';

/// Một lời nhắc hiển thị trong app (dùng cho Windows, nơi chưa có thông báo hệ thống).
class UpcomingReminder {
  final String key; // duy nhất cho mỗi sự kiện -> mỗi lời nhắc chỉ hiện 1 lần
  final String title;
  final String body;
  const UpcomingReminder(this.key, this.title, this.body);
}

/// Nhắc lịch giao / thu hồi loa.
///  - Android: LÊN LỊCH thông báo hệ thống (hiện cả khi đã tắt app). Lịch được tính lại
///    mỗi khi app tải danh sách đơn, nên đơn mới tạo trên máy khác chỉ có nhắc sau khi
///    app này mở và tải lại dữ liệu.
///  - Windows: app tự nhắc bằng thông báo trong app khi đang mở (xem MainShell).
class ReminderService {
  ReminderService._();
  static final ReminderService instance = ReminderService._();

  final _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;
  bool enabled = true;
  int leadMinutes = 60; // nhắc trước bao nhiêu phút

  static bool get supportsSystemNotifications => Platform.isAndroid || Platform.isIOS;

  Future<void> init() async {
    final cfg = await LocalConfigStorage.loadReminder();
    enabled = cfg.enabled;
    leadMinutes = cfg.leadMinutes;
    if (!supportsSystemNotifications) return;
    await _plugin.initialize(
      // iOS: quyền thông báo được hỏi ngay khi khởi tạo (mặc định của DarwinInitializationSettings)
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        iOS: DarwinInitializationSettings(),
      ),
    );
    // Android 13+: hỏi quyền hiện thông báo
    if (Platform.isAndroid) {
      await _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    }
    _ready = true;
  }

  Future<void> configure({bool? enabled, int? leadMinutes, List<Booking>? bookings}) async {
    if (enabled != null) this.enabled = enabled;
    if (leadMinutes != null) this.leadMinutes = leadMinutes;
    await LocalConfigStorage.saveReminder(enabled: this.enabled, leadMinutes: this.leadMinutes);
    if (bookings != null) await sync(bookings);
  }

  static String _hm(DateTime t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  static String _body(Booking b) {
    final s = b.services.map((x) => x.qty > 1 ? '${x.name} ×${x.qty}' : x.name).join(', ');
    return '${b.customerName} · ${b.customerPhone}\n$s';
  }

  /// Sự kiện còn phải làm của đơn: (là giao?, giờ).
  static List<(bool, DateTime)> _events(Booking b) => [
        if (b.status == BookingStatus.pending && b.installTime != null) (true, b.installTime!),
        if (b.status == BookingStatus.delivered && b.collectTime != null) (false, b.collectTime!),
      ];

  static int _id(String bookingId, bool delivery) => ((bookingId.hashCode & 0x3fffffff) * 2) + (delivery ? 0 : 1);

  /// Đặt lại toàn bộ lịch nhắc theo danh sách đơn hiện tại (14 ngày tới, tối đa 60 thông báo;
  /// iOS chỉ cho phép tối đa 64 thông báo chờ nên con số 60 vẫn an toàn).
  Future<void> sync(List<Booking> bookings) async {
    if (!_ready) return;
    try {
      await _plugin.cancelAll();
      if (!enabled) return;
      final now = DateTime.now();
      final horizon = now.add(const Duration(days: 14));
      var count = 0;
      for (final b in bookings) {
        for (final (isDelivery, time) in _events(b)) {
          final when = time.subtract(Duration(minutes: leadMinutes));
          if (!when.isAfter(now) || when.isAfter(horizon) || count >= 60) continue;
          await _plugin.zonedSchedule(
            _id(b.id, isDelivery),
            isDelivery ? 'Sắp tới giờ GIAO loa · ${_hm(time)}' : 'Sắp tới giờ THU HỒI loa · ${_hm(time)}',
            _body(b),
            // Chỉ cần đúng thời điểm tuyệt đối nên dùng UTC làm múi giờ tham chiếu
            tz.TZDateTime.from(when, tz.UTC),
            const NotificationDetails(
              android: AndroidNotificationDetails(
                'dctech_reminders',
                'Nhắc lịch giao / thu loa',
                channelDescription: 'Nhắc trước giờ giao hoặc thu hồi loa',
                importance: Importance.high,
                priority: Priority.high,
              ),
              iOS: DarwinNotificationDetails(presentAlert: true, presentSound: true, presentBadge: true),
            ),
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          );
          count++;
        }
      }
    } catch (_) {
      // Không để lỗi thông báo làm hỏng luồng chính
    }
  }

  /// Các việc sắp tới giờ trong [leadMinutes] phút tới (hoặc vừa quá giờ dưới 30 phút).
  List<UpcomingReminder> upcoming(List<Booking> bookings, DateTime now) {
    if (!enabled) return const [];
    final out = <UpcomingReminder>[];
    for (final b in bookings) {
      for (final (isDelivery, time) in _events(b)) {
        final mins = time.difference(now).inMinutes;
        if (mins <= leadMinutes && mins >= -30) {
          out.add(UpcomingReminder(
            '${b.id}:${isDelivery ? 'giao' : 'thu'}:${time.millisecondsSinceEpoch}',
            isDelivery ? 'Sắp tới giờ GIAO loa · ${_hm(time)}' : 'Sắp tới giờ THU HỒI loa · ${_hm(time)}',
            _body(b).replaceAll('\n', ' · '),
          ));
        }
      }
    }
    return out;
  }
}
