import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/map_link.dart';
import '../../../core/utils/slip_renderer.dart';
import '../../../data/models/booking_model.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/booking_provider.dart';
import '../slip/slip_screen.dart';
import 'add_booking_screen.dart';

/// Danh sách đơn: tìm kiếm, lọc trạng thái, bấm để sửa, nút nhanh Giao/Thu loa.
class BookingListScreen extends StatefulWidget {
  const BookingListScreen({super.key});
  @override
  State<BookingListScreen> createState() => _BookingListScreenState();
}

class _BookingListScreenState extends State<BookingListScreen> {
  final _search = TextEditingController();
  BookingStatus? _filter; // null = tất cả

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _reload());
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg), backgroundColor: AppColors.red));
  }

  Future<void> _reload() async {
    final user = context.read<AuthProvider>().currentUser;
    if (user == null) return;
    try {
      await context.read<BookingProvider>().load(user);
    } catch (e) {
      _snack('Không tải được danh sách đơn: $e');
    }
  }

  bool get _isMobile => Platform.isAndroid || Platform.isIOS;

  Future<void> _openMap(Booking b) async {
    if (!await MapLink.open(link: b.mapLink, gps: b.gpsLocation)) _snack('Không mở được bản đồ.');
  }

  Future<void> _call(Booking b) async {
    if (!await MapLink.call(b.customerPhone)) _snack('Không mở được ứng dụng gọi điện.');
  }

  void _openSlip(Booking b, SlipKind k) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => SlipScreen(booking: b, kind: k)));

  /// "Giao loa" / "Thu loa": mở form đơn với trạng thái mới và phần chụp ảnh.
  void _openForStatus(Booking b) => Navigator.push<bool>(
        context,
        MaterialPageRoute(
          builder: (_) => AddBookingScreen(
            booking: b,
            presetStatus: b.status == BookingStatus.pending ? BookingStatus.delivered : BookingStatus.returned,
          ),
        ),
      );

  Color _statusColor(BookingStatus s) => switch (s) {
        BookingStatus.pending => AppColors.orange,
        BookingStatus.delivered => AppColors.blue,
        BookingStatus.returned => AppColors.green,
      };

  @override
  Widget build(BuildContext context) {
    final p = context.watch<BookingProvider>();
    final q = _search.text.trim().toLowerCase();
    final list = p.bookings.where((b) {
      if (_filter != null && b.status != _filter) return false;
      if (q.isEmpty) return true;
      return b.customerName.toLowerCase().contains(q) ||
          b.customerPhone.contains(q) ||
          b.id.toLowerCase().contains(q);
    }).toList();

    return SafeArea(
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('DANH SÁCH ĐƠN HÀNG',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                hintText: 'Tìm khách hàng, SĐT, mã đơn...',
                prefixIcon: Icon(Icons.search),
              ),
            ),
            const SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _chip('Tất cả', null),
                for (final s in BookingStatus.values) _chip(s.label, s),
              ]),
            ),
          ]),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _reload,
            child: p.loading && p.bookings.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : list.isEmpty
                    ? ListView(children: const [
                        SizedBox(height: 120),
                        Center(child: Text('Chưa có đơn hàng nào', style: TextStyle(color: AppColors.textMuted))),
                      ])
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 90),
                        itemCount: list.length,
                        // Khóa theo mã đơn: khi lọc / tải lại, Flutter ghép đúng thẻ cũ với thẻ mới
                        findChildIndexCallback: (key) {
                          final id = (key as ValueKey<String>).value;
                          final index = list.indexWhere((b) => b.id == id);
                          return index < 0 ? null : index;
                        },
                        itemBuilder: (_, i) => KeyedSubtree(key: ValueKey(list[i].id), child: _card(list[i])),
                      ),
          ),
        ),
      ]),
    );
  }

  Widget _chip(String label, BookingStatus? value) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: _filter == value,
          selectedColor: AppColors.orange,
          onSelected: (_) => setState(() => _filter = value),
        ),
      );

  Widget _card(Booking b) {
    final color = _statusColor(b.status);
    final services = b.services.map((s) => s.qty > 1 ? '${s.name} ×${s.qty}' : s.name).join(', ');
    return Card(
      color: AppColors.surface,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.push<bool>(
            context, MaterialPageRoute(builder: (_) => AddBookingScreen(booking: b))),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text('Mã: #${b.id}',
                    style: const TextStyle(color: AppColors.blue, fontSize: 17, fontWeight: FontWeight.w800)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(color: color.withValues(alpha: 0.25), borderRadius: BorderRadius.circular(20)),
                child: Text(b.status.label, style: TextStyle(color: color, fontWeight: FontWeight.w700)),
              ),
            ]),
            const Divider(height: 18),
            _row(Icons.person_outline, 'Khách: ${b.customerName} - ${b.customerPhone}'),
            _row(Icons.speaker_outlined, 'Dịch vụ: $services'),
            _row(Icons.event_outlined, 'Hạn thu: ${Fmt.dateTime(b.collectTime)}'),
            Row(children: [
              const Icon(Icons.account_balance_wallet_outlined, size: 20, color: AppColors.textMuted),
              const SizedBox(width: 8),
              Expanded(
                child: Text.rich(TextSpan(children: [
                  TextSpan(text: 'Công nợ: ${Fmt.money(b.debtAmount < 0 ? 0 : b.debtAmount)} / '),
                  TextSpan(
                    text: b.pendingToCompany > 0
                        ? 'Chưa nộp cty ${Fmt.money(b.pendingToCompany)}'
                        : 'Đã nộp cty',
                    style: TextStyle(color: b.pendingToCompany > 0 ? AppColors.orange : AppColors.green),
                  ),
                ])),
              ),
            ]),
            const SizedBox(height: 6),
            Row(children: [
              if (b.mapLink.isNotEmpty || b.gpsLocation.isNotEmpty)
                IconButton(
                  tooltip: 'Mở bản đồ',
                  icon: const Icon(Icons.location_on, color: AppColors.orange),
                  onPressed: () => _openMap(b),
                ),
              if (_isMobile)
                IconButton(
                  tooltip: 'Gọi khách',
                  icon: const Icon(Icons.phone, color: AppColors.green),
                  onPressed: () => _call(b),
                ),
              PopupMenuButton<SlipKind>(
                tooltip: 'In phiếu',
                icon: const Icon(Icons.print_outlined, color: AppColors.textMuted),
                onSelected: (k) => _openSlip(b, k),
                itemBuilder: (_) => [for (final k in SlipKind.values) PopupMenuItem(value: k, child: Text(k.label))],
              ),
              const Spacer(),
              if (b.status != BookingStatus.returned)
                FilledButton.tonalIcon(
                  onPressed: () => _openForStatus(b),
                  icon: const Icon(Icons.photo_camera_outlined, size: 18),
                  label: Text(b.status == BookingStatus.pending ? 'Giao loa' : 'Thu loa'),
                ),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _row(IconData icon, String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(children: [
          Icon(icon, size: 20, color: AppColors.textMuted),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ]),
      );
}
